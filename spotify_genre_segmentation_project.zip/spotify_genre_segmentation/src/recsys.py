"""
Spotify Songs' Genre Segmentation - core library
Pre-processing, clustering and content-based recommendation engine.
"""
from __future__ import annotations
import re
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

AUDIO_FEATURES = [
    "danceability", "energy", "loudness", "speechiness", "acousticness",
    "instrumentalness", "liveness", "valence", "tempo", "duration_ms",
]
SKEWED = ["speechiness", "acousticness", "instrumentalness", "liveness"]
WINSOR = ["loudness", "tempo", "duration_ms"]


# ----------------------------------------------------------------- cleaning
def load_raw(path) -> pd.DataFrame:
    return pd.read_csv(path)


def clean(raw: pd.DataFrame) -> pd.DataFrame:
    """Return one row per unique song with cleaned fields.

    Steps: drop rows with missing names -> aggregate duplicate track_ids
    (same song in several playlists) -> remove same-title/same-artist
    duplicates -> parse release dates -> remove invalid audio rows.
    """
    df = raw.dropna(subset=["track_name", "track_artist", "track_album_name"]).copy()

    # a song can sit in several playlists: keep every genre it appears in
    multi = (df.groupby("track_id")["playlist_genre"]
               .agg(lambda s: sorted(set(s))).rename("all_genres"))
    n_pl = df.groupby("track_id")["playlist_id"].nunique().rename("n_playlists")

    df = df.sort_values("track_popularity", ascending=False)
    df = df.drop_duplicates("track_id", keep="first")
    df = df.drop_duplicates(["track_name", "track_artist"], keep="first")
    df = df.join(multi, on="track_id").join(n_pl, on="track_id")

    # dates: 'YYYY', 'YYYY-MM' or 'YYYY-MM-DD'
    d = pd.to_datetime(df["track_album_release_date"], errors="coerce", format="mixed")
    df["release_year"] = d.dt.year.astype("Int64")

    # invalid audio rows (tempo 0 / near-silent / <30 s fragments)
    df = df[(df.tempo > 0) & (df.duration_ms >= 30_000) & (df.loudness > -30)]
    df["duration_min"] = df.duration_ms / 60000
    df["track_label"] = df.track_name + " - " + df.track_artist
    return df.reset_index(drop=True)


def build_features(df: pd.DataFrame, scaler: StandardScaler | None = None,
                   bounds: dict | None = None):
    """log-transform skewed features, winsorise outliers, standardise."""
    X = df[AUDIO_FEATURES].astype(float).copy()
    if bounds is None:
        bounds = {c: (X[c].quantile(0.01), X[c].quantile(0.99)) for c in WINSOR}
    for c in WINSOR:
        X[c] = X[c].clip(*bounds[c])
    for c in SKEWED:
        X[c] = np.log1p(X[c] * 10)          # ×10 spreads the 0-1 range before log
    if scaler is None:
        scaler = StandardScaler().fit(X)
    return scaler.transform(X), scaler, bounds


# --------------------------------------------------------------- recommender
class SpotifyRecommender:
    """Cluster-aware content-based recommender."""

    def __init__(self, k: int = 6, random_state: int = 42):
        self.k, self.rs = k, random_state

    def fit(self, df: pd.DataFrame):
        self.df = df.reset_index(drop=True)
        X, self.scaler, self.bounds = build_features(self.df)
        self.X = X
        self.kmeans = KMeans(self.k, n_init=20, random_state=self.rs).fit(X)
        self.df["cluster"] = self.kmeans.labels_
        self.pca = PCA(2, random_state=self.rs).fit(X)
        self.nn = NearestNeighbors(metric="cosine", algorithm="brute").fit(X)
        self._label_index = {s.lower(): i for i, s in enumerate(self.df.track_label)}
        return self

    # ---- lookups
    def search(self, text: str, n: int = 10) -> pd.DataFrame:
        t = text.lower().strip()
        m = self.df[self.df.track_label.str.lower().str.contains(re.escape(t), na=False)]
        return m.sort_values("track_popularity", ascending=False).head(n)[
            ["track_name", "track_artist", "playlist_genre", "cluster", "track_popularity"]]

    def _show(self, idx, sims):
        out = self.df.iloc[idx][["track_name", "track_artist", "playlist_genre",
                                 "playlist_subgenre", "cluster", "track_popularity"]].copy()
        out["similarity"] = np.round(sims, 3)
        return out.reset_index(drop=True)

    def _rank(self, vec, n, mask=None, exclude=None, min_pop=0, per_artist=2):
        sims = (self.X @ vec) / (np.linalg.norm(self.X, axis=1) * np.linalg.norm(vec) + 1e-12)  # cosine similarity
        ok = np.ones(len(self.df), bool) if mask is None else mask.copy()
        ok &= (self.df.track_popularity.values >= min_pop)
        if exclude is not None:
            ok[exclude] = False
        order = np.argsort(-sims)
        picked, seen = [], {}
        for i in order:
            if not ok[i]:
                continue
            a = self.df.track_artist.iat[i]
            if seen.get(a, 0) >= per_artist:             # artist diversity
                continue
            seen[a] = seen.get(a, 0) + 1
            picked.append(i)
            if len(picked) == n:
                break
        return picked, sims[picked]

    # ---- three ways to ask for songs
    def recommend_similar(self, track: str, n: int = 10, same_cluster: bool = True,
                          min_popularity: int = 0, genre: str | None = None) -> pd.DataFrame:
        """Songs similar to a given 'Title - Artist' (or partial title)."""
        key = track.lower().strip()
        idx = self._label_index.get(key)
        if idx is None:
            hit = self.search(track, 1)
            if hit.empty:
                raise KeyError(f"No track matching '{track}'")
            idx = hit.index[0]
        mask = np.ones(len(self.df), bool)
        if same_cluster:
            mask &= self.df.cluster.values == self.df.cluster.iat[idx]
        if genre:
            mask &= self.df.playlist_genre.values == genre
        rows, sims = self._rank(self.X[idx], n, mask, exclude=idx, min_pop=min_popularity)
        return self._show(rows, sims)

    def recommend_for_profile(self, prefs: dict, n: int = 10, genre: str | None = None,
                              min_popularity: int = 0) -> pd.DataFrame:
        """Songs closest to a hand-specified audio profile (e.g. mood sliders)."""
        base = self.df[AUDIO_FEATURES].mean().to_dict()
        base.update(prefs)
        row = pd.DataFrame([base])[AUDIO_FEATURES]
        v, _, _ = build_features(row, self.scaler, self.bounds)
        mask = None if genre is None else (self.df.playlist_genre.values == genre)
        rows, sims = self._rank(v[0], n, mask, min_pop=min_popularity)
        return self._show(rows, sims)

    def recommend_for_playlist(self, tracks: list[str], n: int = 10) -> pd.DataFrame:
        """Songs close to the centroid of several liked tracks."""
        idxs = []
        for t in tracks:
            i = self._label_index.get(t.lower().strip())
            if i is None:
                hit = self.search(t, 1)
                if hit.empty:
                    continue
                i = hit.index[0]
            idxs.append(i)
        if not idxs:
            raise KeyError("None of the tracks were found")
        rows, sims = self._rank(self.X[idxs].mean(axis=0), n, exclude=idxs)
        return self._show(rows, sims)

    # ---- persistence
    def save(self, folder):
        folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, folder / "recommender.joblib", compress=3)

    @staticmethod
    def load(folder) -> "SpotifyRecommender":
        return joblib.load(Path(folder) / "recommender.joblib")
