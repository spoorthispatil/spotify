"""Streamlit demo:  streamlit run app.py"""
import json
import sys
from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px  # noqa: optional (falls back to st.scatter_chart)

sys.path.insert(0, str(Path(__file__).parent / "src"))
from recsys import SpotifyRecommender, AUDIO_FEATURES  # noqa: E402

st.set_page_config(page_title="Spotify Genre Segmentation", page_icon="🎧", layout="wide")


@st.cache_resource
def load():
    rec = SpotifyRecommender.load(Path(__file__).parent / "models")
    names = json.load(open(Path(__file__).parent / "outputs/tables/cluster_names.json"))
    rec.df["cluster_name"] = rec.df.cluster.map(lambda c: names[str(c)])
    return rec


rec = load()
df = rec.df
st.title("🎧 Spotify Songs' Genre Segmentation & Recommender")
st.caption(f"{len(df):,} unique songs · 6 K-Means sonic clusters · content-based recommendations")

tab1, tab2, tab3, tab4 = st.tabs(["Similar songs", "Mood builder", "Cluster explorer", "Playlist clusters"])

with tab1:
    q = st.text_input("Search a song or artist", "Shape of You")
    hits = rec.search(q, 15) if q else pd.DataFrame()
    if hits.empty:
        st.info("Type a song title or artist name.")
    else:
        labels = [f"{r.track_name} - {r.track_artist}" for r in hits.itertuples()]
        pick = st.selectbox("Pick the seed song", labels)
        c1, c2, c3, c4 = st.columns(4)
        n = c1.slider("How many", 5, 25, 10)
        same = c2.checkbox("Stay in the same cluster", True)
        minpop = c3.slider("Min popularity", 0, 80, 30)
        genre = c4.selectbox("Genre filter", ["any"] + sorted(df.playlist_genre.unique()))
        seed = df.loc[hits.index[labels.index(pick)]]
        st.write(f"**Seed cluster:** {seed.cluster_name} · **genre:** {seed.playlist_genre} · popularity {seed.track_popularity}")
        st.dataframe(rec.recommend_similar(pick, n, same, minpop, None if genre == "any" else genre), width="stretch", hide_index=True)

with tab2:
    st.write("Describe the vibe and get the closest songs.")
    c1, c2 = st.columns(2)
    prefs = {
        "energy": c1.slider("Energy", 0.0, 1.0, 0.7), "danceability": c1.slider("Danceability", 0.0, 1.0, 0.65),
        "valence": c1.slider("Positivity (valence)", 0.0, 1.0, 0.5), "acousticness": c2.slider("Acousticness", 0.0, 1.0, 0.15),
        "speechiness": c2.slider("Speechiness", 0.0, 0.6, 0.07), "tempo": c2.slider("Tempo (BPM)", 60, 200, 120),
    }
    g = st.selectbox("Genre", ["any"] + sorted(df.playlist_genre.unique()), key="g2")
    mp = st.slider("Minimum popularity", 0, 80, 30, key="mp2")
    st.dataframe(rec.recommend_for_profile(prefs, 15, None if g == "any" else g, mp), width="stretch", hide_index=True)

with tab3:
    prof = df.groupby("cluster_name")[AUDIO_FEATURES].mean()
    z = (prof - prof.mean()) / prof.std()
    st.subheader("Cluster profiles (z-score)")
    st.dataframe(z.round(2).style.background_gradient(cmap="RdBu_r", axis=None), width="stretch")
    st.subheader("Genre make-up")
    st.dataframe(pd.crosstab(df.cluster_name, df.playlist_genre, normalize="index").round(2).style.background_gradient(cmap="Purples"), width="stretch")
    pc = rec.pca.transform(rec.X)
    samp = df.assign(PC1=pc[:, 0], PC2=pc[:, 1]).sample(5000, random_state=1)
    st.plotly_chart(px.scatter(samp, x="PC1", y="PC2", color="cluster_name", hover_data=["track_name", "track_artist", "playlist_genre"], opacity=.6, height=550), width="stretch")

with tab4:
    pl = pd.read_csv(Path(__file__).parent / "outputs/tables/playlist_clusters.csv")
    st.write("449 playlist names grouped by the average audio profile of their songs.")
    k = st.selectbox("Playlist cluster", sorted(pl.pl_cluster.unique()))
    st.dataframe(pl[pl.pl_cluster == k].sort_values("songs", ascending=False)[["playlist_name", "genre", "songs"] + AUDIO_FEATURES[:8]].round(2), width="stretch", hide_index=True)
