# Spotify Songs' Genre Segmentation & Recommendation System
Major project: unsupervised clustering of Spotify audio features, playlist-level analysis and a content-based recommender.

## What is inside
| Path | Purpose |
|---|---|
| `notebooks/Spotify_Genre_Segmentation.ipynb` | Full executed analysis: pre-processing, 30 figures, correlation matrix, PCA/t-SNE, clustering, genre & playlist-name clusters, recommender + evaluation |
| `src/recsys.py` | Cleaning, feature engineering and the `SpotifyRecommender` class |
| `models/recommender.joblib` | Trained scaler + K-Means (k=6) + PCA + nearest-neighbour index + song table |
| `app.py` | Streamlit web app (similar songs, mood builder, cluster explorer, playlist clusters) |
| `outputs/figures/` | 30 PNG figures |
| `outputs/tables/` | metrics, cluster profiles, clustered songs, playlist clusters, evaluation tables |
| `report/` | Project report (Word + PDF) |
| `data/spotify_songs.csv` | Input data |

## Run
```bash
pip install -r requirements.txt
jupyter notebook notebooks/Spotify_Genre_Segmentation.ipynb   # Run All (~3 min) regenerates everything
streamlit run app.py
```

```python
import sys; sys.path.insert(0, "src")
from recsys import SpotifyRecommender
rec = SpotifyRecommender.load("models")
rec.recommend_similar("Shape of You - Ed Sheeran", n=10, min_popularity=40)
rec.recommend_for_profile({"energy": .9, "danceability": .75, "tempo": 140}, n=10)
rec.recommend_for_playlist(["Shape of You - Ed Sheeran", "Memories - Maroon 5"])
```

## Headline results
* 32,833 rows -> 26,222 unique songs after cleaning
* Best model: K-Means, k = 6 (silhouette 0.116, Davies-Bouldin 1.92); six named clusters
* Clusters vs playlist genre: ARI 0.075 - audio and genre only partly agree (random forest on audio: 55.1% genre accuracy)
* Playlist-name clustering (449 playlists): silhouette ~0.20
* Recommender: 38.8% genre precision@10 vs 16.8% random (2.3x), ~3 ms per query
